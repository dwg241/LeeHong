import time


def send():
   
    print('okdd')
    time.sleep(1)
    print('ok')
    time.sleep(1)

while 1:
    a= send()
