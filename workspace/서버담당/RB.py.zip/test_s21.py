
import time

from datetime import datetime
now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
Dtime=str(now)
print(Dtime)